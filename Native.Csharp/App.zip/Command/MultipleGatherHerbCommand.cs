﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Native.Csharp.App.Gameplay;
using Native.Csharp.App.Gameplay.Handler;
using Native.Csharp.App.UserInteract;
using Native.Csharp.App.Util;

namespace Native.Csharp.App.Command
{
    class MultipleGatherHerbCommand : ICommand
    {
        public void Execute(Player sender, params string[] args)
        {
            MessageSender mSender = Plugin.GetMessageSender();

            string result;
            int quantity = 0;
            bool isCommandValid = true;

            try
            {
                quantity = int.Parse(args[1]);
            }
            catch(FormatException) //文本无法被转换成数字
            {
                isCommandValid = false;

                mSender.Send(sender.LastGroupID, "数量" + args[1] + "无效！");
            }
            catch(ArgumentNullException) //null问题
            {
                isCommandValid = false;

                mSender.Send(sender.LastGroupID, "命令执行失败。");
                //怎么可能发生这个？！
                mSender.DebugSend("玩家" + sender.GetName() + "在执行MultipleGatherHerbCommand时出现ArgumentNullException。");
            }
            catch(OverflowException)
            {
                //？？瞎搞
                isCommandValid = false;

                //看看是谁采那么多
                mSender.Send(sender.LastGroupID, sender.GetName() + "，给我站住，你采那么多是要把整个地球都搬走吗？！");
            }
            finally
            {
                if(quantity <= 0)
                {
                    isCommandValid = false;
                    mSender.Send(sender.LastGroupID, sender.GetName() + "，不想采就别采！");
                }
                if (quantity > 10)
                {
                    //采那么多干嘛
                    isCommandValid = false;

                    //看看是谁采那么多
                    mSender.Send(sender.LastGroupID ,sender.GetName() + "你采那么多干嘛！别人都没得采了（x");
                }
                    
            }

            if(isCommandValid)
            {
                ItemHandler handler = Plugin.GetItemHandler();

                //TODO:获取更好的RandomTable
                RandomTable table = handler.DefaultRandomTable;

                //初始化返回文本
                result = sender.GetName() + "采集到了：";

                for(int i = 0; i < quantity; i++)
                {
                    table.DoRandomize();
                    Item item = (Item)table.GetResult().Content;

                    sender.Inventory.AddItem(item);
                    result += item.ItemName + "、";
                }
                mSender.Send(sender.LastGroupID, result.TrimEnd('、'));
            }
        }
    }
}
