﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Native.Csharp.App.Gameplay
{
    public class CharacterFlag
    {
        public string Name { get; private set; }
        public string Content { get; set; }

        public const string FlagJobCurrent = "JobCurrent";
        public const string FlagJobHerbAmount = "JobHerbAmount";

        /// <summary>
        /// 构造方法：不能包括空格或分号
        /// </summary>
        /// <param name="name">名字；不能包括空格或分号</param>
        /// <param name="content">内容；不能包括空格或分号</param>
        public CharacterFlag(string name, string content)
        {
            Name = name;
            Content = content;
        }

        public CharacterFlag Parse(string strFlag)
        {
            string[] flag = strFlag.TrimEnd(';').Split(' ');

            return new CharacterFlag(flag[0], flag[1]);
        }

        public override string ToString()
        {
            return Name + " " + Content + ";";
        }
    }
}
