﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Native.Csharp.App.Event
{
    public class EventProcessor
    {
        //基础玩家事件
        public delegate void PlayerCommandHandler();
    }
}
